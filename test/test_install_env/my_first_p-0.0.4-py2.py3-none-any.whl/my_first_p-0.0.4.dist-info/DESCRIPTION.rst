===========================
 my_first_p -- Description
===========================


my_first_p is a Python ....


Documentation
-------------

Documentation for my_first_p is hosted at http://username.github.io/my_first_p


Status
------

.. image:: https://secure.travis-ci.org/username/my_first_p.png?branch=master
    :target: http://travis-ci.org/username/my_first_p

.. image:: https://coveralls.io/repos/username/my_first_p.png?branch=master
    :target: https://coveralls.io/r/username/my_first_p?branch=master
    :alt: Coverage Status


